package edu.purdue.cs.Listener;

/**
 * Created by Bowie on 2016/4/28.
 */
public interface onFinishedListener {
    public void onFinishedParsed(String parsed);
}
