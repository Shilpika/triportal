package edu.purdue.cs.Listener;

import android.view.View;

/**
 * Created by Bowie on 2016/4/18.
 */
public interface OnRefreshListener {
    public void onRefresh(View v);
}
